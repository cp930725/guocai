<input type="hidden" name="playedGroup" value="<?= $this->groupId ?>" />
<input type="hidden" name="playedId" value="<?= $this->played ?>" />
<input type="hidden" name="type" value="<?= $this->type ?>" />
	<div class="dGameStatus hklhc" action="tzlhcSelect" length="1">
    
        <span class="sTitle">平特肖<span class="sNote"><!--&nbsp;(&nbsp;最低限额：5&nbsp;)(&nbsp;单注限额：30,000&nbsp;)(&nbsp;单号限额：100,000&nbsp;)--></span></span>
        <table>
            <tbody><tr>
    
            <td width="40"><span class="sGameStatusItem">鼠</span></td>
            <td>
    
                <span class="sNumL">08</span>
    
                <span class="sNumL">20</span>
    
                <span class="sNumL">32</span>
    
                <span class="sNumL">44</span>
    
            </td>
            <td class="boldborder"><span class="sRte" id="RteLTTA01" style="color: BLUE;"><?= $this->getLHCRte('RteLTTA01', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTA01" name="LTTBP" acno="鼠"></td>
    
            <td width="40"><span class="sGameStatusItem">马</span></td>
            <td>
    
                <span class="sNumL">02</span>
    
                <span class="sNumL">14</span>
    
                <span class="sNumL">26</span>
    
                <span class="sNumL">38</span>
    
            </td>
            <td class=""><span class="sRte" id="RteLTTA07" style="color: BLUE;"><?= $this->getLHCRte('RteLTTA07', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTA07" name="LTTBP" acno="马"></td>
    </tr><tr>

            <td width="40"><span class="sGameStatusItem">牛</span></td>
            <td>
    
                <span class="sNumL">07</span>
    
                <span class="sNumL">19</span>
    
                <span class="sNumL">31</span>
    
                <span class="sNumL">43</span>
    
            </td>
            <td class="boldborder"><span class="sRte" id="RteLTTA02" style="color: BLUE;"><?= $this->getLHCRte('RteLTTA02', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTA02" name="LTTBP" acno="牛"></td>
    
            <td width="40"><span class="sGameStatusItem">羊</span></td>
            <td>

			    <span class="sNumL">01</span>
    
                <span class="sNumL">13</span>
    
                <span class="sNumL">25</span>
    
                <span class="sNumL">37</span>
    
                <span class="sNumL">49</span>
    
            </td>
            <td class=""><span class="sRte" id="RteLTTA08" style="color: BLUE;"><?= $this->getLHCRte('RteLTTA08', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTA08" name="LTTBP" acno="羊"></td>
    </tr><tr>

            <td width="40"><span class="sGameStatusItem">虎</span></td>
            <td>
    
                <span class="sNumL">06</span>
    
                <span class="sNumL">18</span>
    
                <span class="sNumL">30</span>
    
                <span class="sNumL">42</span>
    
            </td>
            <td class="boldborder"><span class="sRte" id="RteLTTA03" style="color: BLUE;"><?= $this->getLHCRte('RteLTTA03', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTA03" name="LTTBP" acno="虎"></td>
    
            <td width="40"><span class="sGameStatusItem">猴</span></td>
            <td>
    
                <span class="sNumL">12</span>
    
                <span class="sNumL">24</span>
    
                <span class="sNumL">36</span>
    
                <span class="sNumL">48</span>
    
            </td>
            <td class=""><span class="sRte" id="RteLTTA09" style="color: BLUE;"><?= $this->getLHCRte('RteLTTA09', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTA09" name="LTTBP" acno="猴"></td>
    </tr><tr>

            <td width="40"><span class="sGameStatusItem">兔</span></td>
            <td>
    
                <span class="sNumL">05</span>
    
                <span class="sNumL">17</span>
    
                <span class="sNumL">29</span>
    
                <span class="sNumL">41</span>
    
            </td>
            <td class="boldborder"><span class="sRte" id="RteLTTA04" style="color: BLUE;"><?= $this->getLHCRte('RteLTTA04', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTA04" name="LTTBP" acno="兔"></td>
    
            <td width="40"><span class="sGameStatusItem">鸡</span></td>
            <td>
    
                <span class="sNumL">11</span>
    
                <span class="sNumL">23</span>
    
                <span class="sNumL">35</span>
    
                <span class="sNumL">47</span>
    
            </td>
            <td class=""><span class="sRte" id="RteLTTA10" style="color: BLUE;"><?= $this->getLHCRte('RteLTTA10', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTA10" name="LTTBP" acno="鸡"></td>
    </tr><tr>

            <td width="40"><span class="sGameStatusItem">龙</span></td>
            <td>
    
                <span class="sNumL">04</span>
    
                <span class="sNumL">16</span>
    
                <span class="sNumL">28</span>
    
                <span class="sNumL">40</span>
    
            </td>
            <td class="boldborder"><span class="sRte" id="RteLTTA05" style="color: BLUE;"><?= $this->getLHCRte('RteLTTA05', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTA05" name="LTTBP" acno="龙"></td>
    
            <td width="40"><span class="sGameStatusItem">狗</span></td>
            <td>
    
                <span class="sNumL">10</span>
    
                <span class="sNumL">22</span>
    
                <span class="sNumL">34</span>
    
                <span class="sNumL">46</span>
    
            </td>
            <td class=""><span class="sRte" id="RteLTTA11" style="color: BLUE;"><?= $this->getLHCRte('RteLTTA11', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTA11" name="LTTBP" acno="狗"></td>
    </tr><tr>

            <td width="40"><span class="sGameStatusItem">蛇</span></td>
            <td>
    
                <span class="sNumL">03</span>
    
                <span class="sNumL">15</span>
    
                <span class="sNumL">27</span>
    
                <span class="sNumL">39</span>
    
            </td>
            <td class="boldborder"><span class="sRte" id="RteLTTA06" style="color: BLUE;"><?= $this->getLHCRte('RteLTTA06', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTA06" name="LTTBP" acno="蛇"></td>
    
            <td width="40"><span class="sGameStatusItem">猪</span></td>
            <td>
    
                <span class="sNumL">09</span>
    
                <span class="sNumL">21</span>
    
                <span class="sNumL">33</span>
    
                <span class="sNumL">45</span>
    
            </td>
            <td class=""><span class="sRte" id="RteLTTA12" style="color: BLUE;"><?= $this->getLHCRte('RteLTTA12', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTA12" name="LTTBP" acno="猪"></td>
    </tr>

        </tbody></table>
        <div class="space"></div>
    </div>
    <div class="dGameStatus hklhc" action="tzlhcSelect" length="1">
    
        <span class="sTitle">平特尾<span class="sNote"><!--&nbsp;(&nbsp;最低限额：5&nbsp;)(&nbsp;单注限额：30,000&nbsp;)(&nbsp;单号限额：100,000&nbsp;)--></span></span>
        <table>
            <tbody><tr>
    
                <td width="35"><span class="sGameStatusItem">0尾</span></td>
                <td class="boldborder"><span class="sRte" id="RteLTTSD0" style="color: BLUE;"><?= $this->getLHCRte('RteLTTSD0', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTSD0" name="LTTSD" acno="0尾"></td>
    
                <td width="35"><span class="sGameStatusItem">1尾</span></td>
                <td class="boldborder"><span class="sRte" id="RteLTTSD1" style="color: BLUE;"><?= $this->getLHCRte('RteLTTSD1', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTSD1" name="LTTSD" acno="1尾"></td>
    
                <td width="35"><span class="sGameStatusItem">2尾</span></td>
                <td class="boldborder"><span class="sRte" id="RteLTTSD2" style="color: BLUE;"><?= $this->getLHCRte('RteLTTSD2', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTSD2" name="LTTSD" acno="2尾"></td>
    
                <td width="35"><span class="sGameStatusItem">3尾</span></td>
                <td class="boldborder"><span class="sRte" id="RteLTTSD3" style="color: BLUE;"><?= $this->getLHCRte('RteLTTSD3', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTSD3" name="LTTSD" acno="3尾"></td>
    
                <td width="35"><span class="sGameStatusItem">4尾</span></td>
                <td class=""><span class="sRte" id="RteLTTSD4" style="color: BLUE;"><?= $this->getLHCRte('RteLTTSD4', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTSD4" name="LTTSD" acno="4尾"></td>
    </tr><tr>

                <td width="35"><span class="sGameStatusItem">5尾</span></td>
                <td class="boldborder"><span class="sRte" id="RteLTTSD5" style="color: BLUE;"><?= $this->getLHCRte('RteLTTSD5', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTSD5" name="LTTSD" acno="5尾"></td>
    
                <td width="35"><span class="sGameStatusItem">6尾</span></td>
                <td class="boldborder"><span class="sRte" id="RteLTTSD6" style="color: BLUE;"><?= $this->getLHCRte('RteLTTSD6', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTSD6" name="LTTSD" acno="6尾"></td>
    
                <td width="35"><span class="sGameStatusItem">7尾</span></td>
                <td class="boldborder"><span class="sRte" id="RteLTTSD7" style="color: BLUE;"><?= $this->getLHCRte('RteLTTSD7', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTSD7" name="LTTSD" acno="7尾"></td>
    
                <td width="35"><span class="sGameStatusItem">8尾</span></td>
                <td class="boldborder"><span class="sRte" id="RteLTTSD8" style="color: BLUE;"><?= $this->getLHCRte('RteLTTSD8', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTSD8" name="LTTSD" acno="8尾"></td>
    
                <td width="35"><span class="sGameStatusItem">9尾</span></td>
                <td class=""><span class="sRte" id="RteLTTSD9" style="color: BLUE;"><?= $this->getLHCRte('RteLTTSD9', $this->played) ?></span><input type="text" maxlength="5" id="CdtLTTSD9" name="LTTSD" acno="9尾"></td>
    </tr>

        </tbody></table>
        <div class="space"></div>
    </div>
    
    <div id="dResult">
        <input type="button" value="重设" onclick="resetTotalCredit();" name="重设">
        <input type="button" value="确定" onclick="bringRte();" name="确定">
        <span id="sTotalCredit" class="sTotal FontBold">0</span>
        <span>总计额度</span>
    </div>
    <div class="space"></div>
