﻿
             
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                            <h4 class="modal-title"><?= $args[0]['title'] ?></h4>
                                        </div>
                                        <div class="modal-body">
                                            <p><strong>【杏彩公告】</strong> <?= nl2br($args[0]['content']) ?></p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-primary" data-dismiss="modal">关闭</button>
                                           
                                        </div>
                             
				