<?php $this->display('inc_daohang.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>杏彩娱乐-官方网站</title>
        <link rel="stylesheet" type="text/css" href="/css/nsc/home/reset.css?v=1.16.11.6" />

        <script type="text/javascript" src="/js/nsc/jquery-1.7.min.js?v=1.16.11.6"></script>
        <script type="text/javascript" src="/js/nsc/base.js?v=1.16.11.6"></script>
        <script type="text/javascript" src="/js/nsc/jquery-1.7.min.js?v=1.16.11.6"></script>
			<link rel="stylesheet" href="/css/nsc/huodong.css?v=1.16.11.6" />
        <script type="text/javascript" src="/js/nsc/dialogUI/jquery.dialogUI.js?v=1.16.11.6"></script>
        <script type="text/javascript" src="/js/nsc/main.js?v=1.16.11.6"></script>

        <link href="/css/nsc/plugin/dialogUI/dialogUI.css?v=1.16.11.6" media="all" type="text/css" rel="stylesheet" />
    </head>
    <body>
        <div id="contentBox" class="activity_main">
            <div class="right_meun" id="siderbar">
                <div class="r_tit-bg"><h3 class="r_tit">热门活动</h3></div>
                <ul>
			        	<li >
			                <a href="zadan">赛马砸蛋活动</a>
			            </li>
			            <li >
			                <a href="/index.php/score/chuangguan">至尊闯关活动</a>
			            </li>
			            <li >
			                <a href="/index.php/score/chongzhi">充值福利</a>
			            </li>
			            <li class="current">
			                <a href="/index.php/score/qiandao">签到有你</a>
			            </li>
			            <li >
			                <a href="/index.php/score/yongjin">新至尊佣金活动</a>
			            </li>
			            <li >
			                <a href="?controller=promotionsnew&action=ptcommission" target="mainFrame">PT活动</a>
			            </li>
			    </ul>
            </div>
            <div class="left_activity">

<div id="subContent_bet_re">
<div class="activity_content" id="content">
    <div class="activity_banner" style="background:url(/images/nsc/activity/activity_banner05.jpg) no-repeat;"></div>
    <div class="activity_title">
    	<h2>签到有你</h2>
        <input type="hidden" name="submit_times" id="submit_times" value="0" />
			<input type="hidden" name="islvproxy" id="islvproxy" value="" />
			<p class="countdown">您已累计签到<span id="days">0</span>天</p>
			<a href="javascript:void()" onclick="window.location.href='?controller=promotionsnew&action=qdact'" title="签到" class="check_btn_signIn">签到</a> 
			<a href="javascript:void()" onclick="window.location.href='?controller=promotionsnew&action=special'" title="领取大礼包" class="check_btn">领取大礼包</a>
    </div>
    <div class="activity_nr">
    	<h4 class="x-title">重磅好礼</h4>
        <div class="x-text" class="box_ul1"><p><p> </p> <p>签到领奖金 轻松赚福利</p> <p>为了答谢大家对杏彩的支持！从11月8日至12月7日，杏彩将推出全新的签到送奖金活动，仍然只需投注满666元，就能获得一次抽奖机会，奖金最高达15元！累计签到25天，礼包更高达66元！你还在等待？别人已经成功领取奖金了，赶紧来参加吧！</p> <p>活动时间11月8日00:30至12月7日00:00:00</p> <p>具体内容</p> <p>1、每天完成666投注，上线即可领取签到奖金，奖金有5、10、15元，由系统随机派发</p> <p>2、累计签到7天，即可额外领取礼包16元</p> <p>      累计签到15天，即可额外领取大礼包36元</p> <p>      累计签到25天，即可额外领取超级大礼包66元</p> <p> </p> <p> </p> <p> </p> <p> </p> <p> </p></p></div>
      <h4 class="x-title">注意事项</h4>
        <div class="x-text" class="box_ol1"><p><p> </p> <p>  </p> <p>1、用户每天完成666元彩票投注，打开官网“活动公告”中的“热门活动”，然后点击“签到有你”页面上的“签到”即可领取奖金。</p> <p>2、奖金需要在当天（23:59:59之前）完成领取，隔天无效。</p> <p>3、本次活动仅计算彩票投注金额，且不与其他活动共享。</p> <p>4、同一账户、同一银行卡、同一IP每天只可参加一次活动。</p> <p>5、任何的无风险投注，对冲，对打均不计算有效投注。有效投注定义：玩法投注不得超过该玩法投注最大注数的70%，即定位胆不得超过7注，二星不得超过70注，三星不得超过700注，四星不得超过7000注，五星不得超过70000注。如发现利用活动存在对冲等恶意套利行为，杏彩有权扣除违规所得。</p> <p>6、【杏彩娱乐】有权对此活动随时做出更改、终止，并享有最终解释权。</p> <p> </p> <p> </p></p></div>
    </div>
</div>
﻿</div>
<div style="clear: both"></div>
<script type="text/javascript" src="/js/nsc/soundBox.js?v=1.16.11.6"></script>
<script type="text/javascript" src="/js/nsc/base.js?v=1.16.11.6"></script>
﻿</div>﻿</div>﻿</div>﻿</div>﻿</div>
<?php $this->display('inc_che.php'); ?>

</body>
</html>
