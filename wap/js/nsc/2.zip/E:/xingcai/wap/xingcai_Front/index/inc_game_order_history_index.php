﻿<div class="game_jilu">
       <div class="yx_body">
           <div class="yxlist"  style="height:300px;overflow:scroll;">
             <table border="0" cellpadding="0" cellspacing="0" style="width:100%;">
             <tbody>
             <th >编号</th>
             <th >期号</th>
             <th >倍数</th>
             <th >模式</th>
             <th >状态</th>
             <th >操作</th>
             </tbody>
			 <tbody class="projectlist" id="order-history"><?php $this->display('index/inc_game_order_history.php'); ?></tbody>
             </table>
           </div>
         </div>
       </div>