<input type="hidden" name="playedGroup" value="<?= $this->groupId ?>" />
<input type="hidden" name="playedId" value="<?= $this->played ?>" />
<input type="hidden" name="type" value="<?= $this->type ?>" />
 <div class="dGameStatus hklhc" action="tzlhcSelect" length="1">
    
        <span class="sTitle">特别号生肖<span class="sNote"><!--&nbsp;(&nbsp;最低限额：5&nbsp;)(&nbsp;单注限额：30,000&nbsp;)(&nbsp;单号限额：100,000&nbsp;)--></span></span>
        <table>
        <tbody><tr>
    
            <td width="40">
                <span class="sGameStatusItem">鼠</span>
            </td>
            <td>
    
                <span class="sNumL">08</span>
    
                <span class="sNumL">20</span>
    
                <span class="sNumL">32</span>
    
                <span class="sNumL">44</span>
    
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPA01" style="color: BLUE;"><?= $this->getLHCRte('RteSPA01', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPA01" name="SPANM" acno="鼠">
            </td>
    
            <td width="40">
                <span class="sGameStatusItem">马</span>
            </td>
            <td>
    
                <span class="sNumL">02</span>
    
                <span class="sNumL">14</span>
    
                <span class="sNumL">26</span>
    
                <span class="sNumL">38</span>
    
            </td>
            <td class="">
                <span class="sRte" id="RteSPA07" style="color: BLUE;"><?= $this->getLHCRte('RteSPA07', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPA07" name="SPANM" acno="马">
            </td>
    </tr><tr>

            <td width="40">
                <span class="sGameStatusItem">牛</span>
            </td>
            <td>
    
                <span class="sNumL">07</span>
    
                <span class="sNumL">19</span>
    
                <span class="sNumL">31</span>
    
                <span class="sNumL">43</span>
    
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPA02" style="color: BLUE;"><?= $this->getLHCRte('RteSPA02', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPA02" name="SPANM" acno="牛">
            </td>
    
            <td width="40">
                <span class="sGameStatusItem">羊</span>
            </td>
            <td>

			    <span class="sNumL">01</span>
    
                <span class="sNumL">13</span>
    
                <span class="sNumL">25</span>
    
                <span class="sNumL">37</span>
    
                <span class="sNumL">49</span>
    
            </td>
            <td class="">
                <span class="sRte" id="RteSPA08" style="color: BLUE;"><?= $this->getLHCRte('RteSPA08', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPA08" name="SPANM" acno="羊">
            </td>
    </tr><tr>

            <td width="40">
                <span class="sGameStatusItem">虎</span>
            </td>
            <td>
    
                <span class="sNumL">06</span>
    
                <span class="sNumL">18</span>
    
                <span class="sNumL">30</span>
    
                <span class="sNumL">42</span>
    
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPA03" style="color: BLUE;"><?= $this->getLHCRte('RteSPA03', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPA03" name="SPANM" acno="虎">
            </td>
    
            <td width="40">
                <span class="sGameStatusItem">猴</span>
            </td>
            <td>
    
                <span class="sNumL">12</span>
    
                <span class="sNumL">24</span>
    
                <span class="sNumL">36</span>
    
                <span class="sNumL">48</span>
    
            </td>
            <td class="">
                <span class="sRte" id="RteSPA09" style="color: BLUE;"><?= $this->getLHCRte('RteSPA09', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPA09" name="SPANM" acno="猴">
            </td>
    </tr><tr>

            <td width="40">
                <span class="sGameStatusItem">兔</span>
            </td>
            <td>
    
                <span class="sNumL">05</span>
    
                <span class="sNumL">17</span>
    
                <span class="sNumL">29</span>
    
                <span class="sNumL">41</span>
    
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPA04" style="color: BLUE;"><?= $this->getLHCRte('RteSPA04', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPA04" name="SPANM" acno="兔">
            </td>
    
            <td width="40">
                <span class="sGameStatusItem">鸡</span>
            </td>
            <td>
    
                <span class="sNumL">11</span>
    
                <span class="sNumL">23</span>
    
                <span class="sNumL">35</span>
    
                <span class="sNumL">47</span>
    
            </td>
            <td class="">
                <span class="sRte" id="RteSPA10" style="color: BLUE;"><?= $this->getLHCRte('RteSPA10', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPA10" name="SPANM" acno="鸡">
            </td>
    </tr><tr>

            <td width="40">
                <span class="sGameStatusItem">龙</span>
            </td>
            <td>
    
                <span class="sNumL">04</span>
    
                <span class="sNumL">16</span>
    
                <span class="sNumL">28</span>
    
                <span class="sNumL">40</span>
    
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPA05" style="color: BLUE;"><?= $this->getLHCRte('RteSPA05', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPA05" name="SPANM" acno="龙">
            </td>
    
            <td width="40">
                <span class="sGameStatusItem">狗</span>
            </td>
            <td>
    
                <span class="sNumL">10</span>
    
                <span class="sNumL">22</span>
    
                <span class="sNumL">34</span>
    
                <span class="sNumL">46</span>
    
            </td>
            <td class="">
                <span class="sRte" id="RteSPA11" style="color: BLUE;"><?= $this->getLHCRte('RteSPA11', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPA11" name="SPANM" acno="狗">
            </td>
    </tr><tr>

            <td width="40">
                <span class="sGameStatusItem">蛇</span>
            </td>
            <td>
    
                <span class="sNumL">03</span>
    
                <span class="sNumL">15</span>
    
                <span class="sNumL">27</span>
    
                <span class="sNumL">39</span>
    
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPA06" style="color: BLUE;"><?= $this->getLHCRte('RteSPA06', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPA06" name="SPANM" acno="蛇">
            </td>
    
            <td width="40">
                <span class="sGameStatusItem">猪</span>
            </td>
            <td>
    
                <span class="sNumL">09</span>
    
                <span class="sNumL">21</span>
    
                <span class="sNumL">33</span>
    
                <span class="sNumL">45</span>
    
            </td>
            <td class="">
                <span class="sRte" id="RteSPA12" style="color: BLUE;"><?= $this->getLHCRte('RteSPA12', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPA12" name="SPANM" acno="猪">
            </td>
    </tr>
                 
        </tbody></table>
        <div class="space"></div>
    </div>
     
    <div class="dGameStatus hklhc" action="tzlhcSelect" length="1">
    
        <span class="sTitle">特别号头数<span class="sNote"><!--&nbsp;(&nbsp;最低限额：5&nbsp;)(&nbsp;单注限额：30,000&nbsp;)(&nbsp;单号限额：100,000&nbsp;)--></span></span>
        <table>
        <tbody><tr>
    
            <td width="38">
                <span class="sGameStatusItem">0头</span>
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPTD0" style="color: BLUE;"><?= $this->getLHCRte('RteSPTD0', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPTD0" name="SPTD" acno="0头">
            </td>
    
            <td width="38">
                <span class="sGameStatusItem">1头</span>
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPTD1" style="color: BLUE;"><?= $this->getLHCRte('RteSPTD1', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPTD1" name="SPTD" acno="1头">
            </td>
    
            <td width="38">
                <span class="sGameStatusItem">2头</span>
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPTD2" style="color: BLUE;"><?= $this->getLHCRte('RteSPTD2', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPTD2" name="SPTD" acno="2头">
            </td>
    
            <td width="38">
                <span class="sGameStatusItem">3头</span>
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPTD3" style="color: BLUE;"><?= $this->getLHCRte('RteSPTD3', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPTD3" name="SPTD" acno="3头">
            </td>
    
            <td width="38">
                <span class="sGameStatusItem">4头</span>
            </td>
            <td class="">
                <span class="sRte" id="RteSPTD4" style="color: BLUE;"><?= $this->getLHCRte('RteSPTD4', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPTD4" name="SPTD" acno="4头">
            </td>
    </tr>

        </tbody></table>
        <div class="space"></div>
    </div>
     
    <div class="dGameStatus hklhc" action="tzlhcSelect" length="1">
    
        <span class="sTitle">特别号尾数<span class="sNote"><!--&nbsp;(&nbsp;最低限额：5&nbsp;)(&nbsp;单注限额：30,000&nbsp;)(&nbsp;单号限额：100,000&nbsp;)--></span></span>
        <table>
        <tbody><tr>
    
            <td width="38">
                <span class="sGameStatusItem">0尾</span>
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPSD0" style="color: BLUE;"><?= $this->getLHCRte('RteSPSD0', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPSD0" name="SPSD" acno="0尾">
            </td>
    
            <td width="38">
                <span class="sGameStatusItem">1尾</span>
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPSD1" style="color: BLUE;"><?= $this->getLHCRte('RteSPSD1', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPSD1" name="SPSD" acno="1尾">
            </td>
    
            <td width="38">
                <span class="sGameStatusItem">2尾</span>
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPSD2" style="color: BLUE;"><?= $this->getLHCRte('RteSPSD2', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPSD2" name="SPSD" acno="2尾">
            </td>
    
            <td width="38">
                <span class="sGameStatusItem">3尾</span>
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPSD3" style="color: BLUE;"><?= $this->getLHCRte('RteSPSD3', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPSD3" name="SPSD" acno="3尾">
            </td>
    
            <td width="38">
                <span class="sGameStatusItem">4尾</span>
            </td>
            <td class="">
                <span class="sRte" id="RteSPSD4" style="color: BLUE;"><?= $this->getLHCRte('RteSPSD4', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPSD4" name="SPSD" acno="4尾">
            </td>
    </tr><tr>

            <td width="38">
                <span class="sGameStatusItem">5尾</span>
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPSD5" style="color: BLUE;"><?= $this->getLHCRte('RteSPSD5', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPSD5" name="SPSD" acno="5尾">
            </td>
    
            <td width="38">
                <span class="sGameStatusItem">6尾</span>
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPSD6" style="color: BLUE;"><?= $this->getLHCRte('RteSPSD6', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPSD6" name="SPSD" acno="6尾">
            </td>
    
            <td width="38">
                <span class="sGameStatusItem">7尾</span>
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPSD7" style="color: BLUE;"><?= $this->getLHCRte('RteSPSD7', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPSD7" name="SPSD" acno="7尾">
            </td>
    
            <td width="38">
                <span class="sGameStatusItem">8尾</span>
            </td>
            <td class="boldborder">
                <span class="sRte" id="RteSPSD8" style="color: BLUE;"><?= $this->getLHCRte('RteSPSD8', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPSD8" name="SPSD" acno="8尾">
            </td>
    
            <td width="38">
                <span class="sGameStatusItem">9尾</span>
            </td>
            <td class="">
                <span class="sRte" id="RteSPSD9" style="color: BLUE;"><?= $this->getLHCRte('RteSPSD9', $this->played) ?></span><input type="text" maxlength="5" id="CdtSPSD9" name="SPSD" acno="9尾">
            </td>
    </tr>

        </tbody></table>
        <div class="space"></div>
    </div>
    <div id="dResult">
        <input type="button" value="重设" onclick="resetTotalCredit();" name="重设">
        <input type="button" value="确定" onclick="bringRte();" name="确定">
        <span id="sTotalCredit" class="sTotal FontBold">0</span>
        <span>总计额度</span>
    </div>
    <div class="space"></div>
